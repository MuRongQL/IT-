# 服务价格表 - 静态网站

🎨 现代美观的响应式服务价格表，支持后台管理数据。

## 快速预览

直接在浏览器中打开 `public/index.html` 即可预览前台页面。

## 功能特性

### 前台展示
- 🌐 完全响应式设计（手机/平板/电脑）
- 🎨 现代深色主题 + 动态背景
- ⚡ 无需后端，纯静态页面
- 🔄 支持多标签页数据同步

### 后台管理
- 🔐 密码保护的管理后台
- ✏️ 可视化编辑所有价格项目
- 📝 管理通用规则
- 💾 本地存储（localStorage）
- 📤 数据导入/导出（JSON）
- 🔄 一键重置为默认数据

## 快速部署

### 方式一：Vercel（推荐 ⚡）

1. 访问 [vercel.com](https://vercel.com)
2. 使用 GitHub/GitLab 导入项目
3. 点击 Deploy

**或使用 CLI：**
```bash
npm i -g vercel
cd static-site
vercel
```

### 方式二：Netlify

1. 访问 [netlify.com](https://netlify.com)
2. 拖拽 `static-site/public` 文件夹到页面

**或使用 CLI：**
```bash
npm i -g netlify-cli
cd static-site
netlify deploy --prod --dir=public
```

### 方式三：GitHub Pages（免费）

1. 创建 GitHub 仓库
2. 上传 `static-site` 文件夹内容
3. 进入 Settings → Pages
4. Source 选择 `main` 分支和 `/ (root)` 文件夹
5. 保存后等待部署

**自动部署：** 推送代码后，`.github/workflows/deploy.yml` 自动部署。

### 方式四：Cloudflare Pages

1. 访问 [pages.cloudflare.com](https://pages.cloudflare.com)
2. 连接 GitHub 仓库
3. 构建命令留空，生产目录选择 `public`

### 方式五：任何静态服务器

```bash
# Python
cd static-site/public
python -m http.server 8080

# Node.js
npx serve public

# PHP
cd static-site/public
php -S localhost:8080
```

## 使用说明

### 访问后台管理

1. 打开网站，点击右上角「管理后台」链接
2. 输入管理员密码登录
3. 默认密码：`admin`

### 管理功能

| 功能 | 说明 |
|------|------|
| 添加项目 | 点击分类下的「添加项目」按钮 |
| 编辑项目 | 点击项目右侧的编辑图标 |
| 删除项目 | 点击项目右侧的删除图标 |
| 修改规则 | 直接编辑规则文本框 |
| 添加规则 | 点击「添加规则」按钮 |
| 导出数据 | 点击「导出」下载 JSON 文件 |
| 导入数据 | 点击「导入」粘贴 JSON 数据 |
| 重置数据 | 点击「重置」恢复默认数据 |

### 数据存储

数据存储在浏览器 localStorage 中：
- 不同浏览器数据独立
- 清除浏览器缓存会重置数据
- 建议定期导出备份

## 项目结构

```
static-site/
├── public/
│   ├── index.html      # 前台展示页
│   ├── admin.html     # 后台管理页
│   ├── robots.txt     # SEO 配置
│   └── .nojekyll      # GitHub Pages 配置
├── vercel.json        # Vercel 配置
├── netlify.toml       # Netlify 配置
├── _routes.json       # Cloudflare 配置
├── README.md          # 说明文档
└── .github/
    └── workflows/
        └── deploy.yml  # GitHub Actions 自动部署
```

## 自定义

### 修改样式
编辑 CSS 中的 `:root` 变量即可修改主题色：
```css
:root {
    --accent-ue5: #a855f7;
    --accent-ppt: #f59e0b;
    /* ... */
}
```

### 修改密码
编辑 `admin.html` 中的 `DEFAULT_PASSWORD` 变量：
```javascript
const DEFAULT_PASSWORD = 'your-new-password';
```

### 更换图标
使用 [Phosphor Icons](https://phosphoricons.com)，在代码中替换图标名称：
```html
<i class="ph-fill ph-game-controller"></i>
```

## 技术栈

- HTML5 + CSS3（纯原生，无框架）
- Phosphor Icons（矢量图标）
- Google Fonts Inter（字体）
- localStorage（数据存储）

## 许可证

MIT License - 可自由使用和修改。
